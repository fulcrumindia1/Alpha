"""
views package initialization
"""
